test = {'name': 'q5',
 'points': 6,
 'suites': [{'cases': [{'code': '>>> sequence(6, abs) # Terms are 1, 2, 3, 4, '
                                '5, 6\n'
                                '123456\n'
                                '\n'
                                '>>> sequence(5, lambda k: k+8) # Terms are 9, '
                                '10, 11, 12, 13\n'
                                '910111213\n'
                                '\n'
                                '>>> sequence(4, lambda k: pow(10, k)) # Terms '
                                'are 10, 100, 1000, 10000\n'
                                '10100100010000\n'}],
             'scored': True,
             'setup': 'from q5 import *',
             'type': 'doctest'}]}